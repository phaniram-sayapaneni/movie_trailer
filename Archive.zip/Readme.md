README:
1.) Open the Entertainment_Centre.py file and run it
2.) You will be directed to a web page in your browser
3.) Click on the movie you are interested to see the movie trailer
4.) I have icluded 6 films.
5.) This Project is all about deploying the movie posters on a web page, where you      get to see the trailers of the movies as well. I have used a ready made module called fresh tomatoes which brings all the information in the code to a real browser. 


Thanks!
